#pragma once

int  state_create (const char *);
void state_send   (int, const char *, const char *);
