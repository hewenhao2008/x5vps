# π₁(Glorytun)=ℤ²

Small, Simple and Stupid TCP VPN.

#### Work In Progress

This code will probably format your harddisk!

#### Build and Install

Glorytun depends on [libsodium](https://github.com/jedisct1/libsodium) version >= 1.0.4.

To build and install the latest version:

    $ git clone https://github.com/angt/glorytun
    $ cd glorytun
    $ ./autogen.sh
    $ ./configure
    $ make
    # make install

For feature requests and bug reports, please create an [issue](https://github.com/angt/glorytun/issues).
